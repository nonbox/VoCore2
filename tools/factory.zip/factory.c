// set two antenna: factory 0x34 0x22 > out.bin
// set one antenna: factory 0x34 0x11 > out.bin
// write to factory setting: mtd -e factory write out.bin factory
// in dts, factory section must be writable.

#include <stdio.h>

// convert string to unsigned int.
// hex: 0x, oct: 0, bin: ...b, dec: normal.
unsigned int atox(char* s)
{
    char *p = s, *e = s;
    unsigned int r = 0;

    while(*e != '\0')
	e++;

    if (*p == '0' && (*(p + 1) == 'x' || *(p + 1) == 'X')) {
	// hex: skip first 0x or 0X header.
	p += 2;

	while(p != e) {
	    r <<= 4;
	    r += ((*p >= '0' && *p <= '9') ? (*p - '0') : ((*p >= 'A' && *p <= 'F') ?
		 *p - 'A' + 0xA : ((*p >= 'a' && *p <= 'f') ? *p - 'a' + 0xA : 0)));
	    p++;
	}
    } else if ((e - p) >= 2 && *(e - 1) == 'b') {
	// bin: ignore last b.
	e--;

	while(p != e) {
	    r <<= 1;
	    r += (*p == '0' ? 0 : 1);
	    p++;
	}
    } else if (*p == '0') {
	// oct: skip first 0 header.
	p += 1;

	while(p != e) {
	    r <<= 3;
	    r += ((*p >= '0' && *p <= '7') ? (*p - '0') : 0);
	    p++;
	}
    } else {
	// dec: we do not need to deal the number.
	while(p != e) {
	    r *= 10;
	    r += ((*p >= '0' && *p <= '9') ? (*p - '0') : 0);
	    p++;
	}
    }

    return r;
}

int main(int argc, char *argv[])
{
	FILE *fp;
	char buf[0x10000] = {0};
	int reg, val;

	if (argc != 3) {
		printf("usage: factory [reg 2B] [value 1B] > out.bin\n");
		return 0;
	}

	fp = fopen("/dev/mtd2", "rb");
	if (fp == NULL) {
		printf("can not open factory setting section(/dev/mtd2).\n");
		return -1;
	}

	fread(buf, 1, 0x10000, fp);
	fclose(fp);

	// check magic code.
	if (buf[0] != 0x28 || buf[1] != 0x76) {
		printf("mtd2 is not mt7628 factory setting.\n");
		return -1;
	}

	reg = atox(argv[1]);
	val = atox(argv[2]);

	buf[reg] = val;

	fwrite(buf, 1, 0x10000, stdout);
	fflush(stdout);
	return 0;
}
